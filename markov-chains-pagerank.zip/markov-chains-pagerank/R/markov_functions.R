# From-scratch tools for finite Markov chains and PageRank (base R only).
# Convention: P is a row-stochastic n x n matrix, P[i, j] = Pr(next = j | now = i).
# Distributions are ROW vectors: mu_{t+1} = mu_t %*% P.

#' Random "preferential-attachment-like" undirected graph (adjacency matrix),
#' connected by construction (each new node attaches to >= 1 earlier node).
make_graph <- function(n, m = 2) {
  A <- matrix(0, n, n)
  A[1, 2] <- A[2, 1] <- 1
  for (v in 3:n) {
    deg <- rowSums(A[1:(v - 1), 1:(v - 1), drop = FALSE]) + 1
    k <- min(m, v - 1)
    targets <- sample.int(v - 1, k, prob = deg)
    A[v, targets] <- 1; A[targets, v] <- 1
  }
  A
}

#' Simple random walk on a graph: P = D^-1 A.
walk_matrix <- function(A) A / rowSums(A)

#' Lazy version (I + P)/2: aperiodic even on bipartite graphs.
lazy <- function(P) (diag(nrow(P)) + P) / 2

#' Stationary distribution as the left eigenvector for eigenvalue 1.
stationary_eigen <- function(P) {
  e <- eigen(t(P))
  v <- Re(e$vectors[, which.max(Re(e$values))])
  v / sum(v)
}

#' Total variation distance between two distributions.
tv <- function(mu, nu) 0.5 * sum(abs(mu - nu))

#' Dobrushin ergodicity coefficient: max over row pairs of TV(P[i,], P[k,]).
#' TV(mu P, nu P) <= dobrushin(P) * TV(mu, nu)  (proved in the report).
dobrushin <- function(P) {
  n <- nrow(P); best <- 0
  for (i in seq_len(n - 1)) for (k in (i + 1):n) best <- max(best, tv(P[i, ], P[k, ]))
  best
}

#' Doeblin minorisation constant: delta = sum_j min_i P[i, j].
#' Then dobrushin(P) <= 1 - delta.
doeblin_delta <- function(P) sum(apply(P, 2, min))

#' TV distance to stationarity after t steps from a start state, for t = 0..T.
tv_decay <- function(P, pi, start, T) {
  mu <- numeric(nrow(P)); mu[start] <- 1
  out <- numeric(T + 1)
  for (t in 0:T) { out[t + 1] <- tv(mu, pi); mu <- mu %*% P }
  out
}

#' Worst-case (over start states) TV distance after t steps.
worst_tv <- function(P, pi, T) {
  d <- vapply(seq_len(nrow(P)), function(s) tv_decay(P, pi, s, T), numeric(T + 1))
  apply(d, 1, max)
}

#' Expected hitting times of a target set: h[i] = 0 on the target and
#' h[i] = 1 + sum_j P[i,j] h[j] elsewhere, i.e. (I - Q) h = 1 with Q = P
#' restricted to the non-target states.
hitting_times <- function(P, target) {
  n <- nrow(P); rest <- setdiff(seq_len(n), target)
  h <- numeric(n)
  h[rest] <- solve(diag(length(rest)) - P[rest, rest, drop = FALSE], rep(1, length(rest)))
  h
}

#' Monte Carlo estimate of the expected hitting time from `start`.
simulate_hitting <- function(P, start, target, reps = 4000) {
  n <- nrow(P)
  cum <- t(apply(P, 1, cumsum))
  steps <- numeric(reps)
  for (r in seq_len(reps)) {
    s <- start; k <- 0
    while (!(s %in% target)) { s <- which(runif(1) <= cum[s, ])[1]; k <- k + 1 }
    steps[r] <- k
  }
  c(mean = mean(steps), se = sd(steps) / sqrt(reps))
}

# ---- PageRank --------------------------------------------------------

#' Google matrix G = d * P + (1 - d) * 1 v', where dangling rows (no
#' out-links) are first replaced by the teleport distribution v.
#' `L` is a 0/1 link matrix, L[i, j] = 1 if page i links to page j.
google_matrix <- function(L, d = 0.85, v = rep(1 / nrow(L), nrow(L))) {
  n <- nrow(L); out <- rowSums(L)
  P <- L / ifelse(out == 0, 1, out)
  P[out == 0, ] <- matrix(v, sum(out == 0), n, byrow = TRUE)
  d * P + (1 - d) * matrix(v, n, n, byrow = TRUE)
}

#' PageRank by power iteration; returns the vector and the iteration count.
pagerank_power <- function(G, tol = 1e-12, max_iter = 10000) {
  n <- nrow(G); x <- rep(1 / n, n)
  for (it in seq_len(max_iter)) {
    x_new <- as.vector(x %*% G)
    if (sum(abs(x_new - x)) < tol) return(list(x = x_new, iterations = it))
    x <- x_new
  }
  list(x = x, iterations = max_iter)
}

#' PageRank by a direct linear solve: x (I - d P) = (1 - d) v, valid when
#' x sums to 1 (see the report). Here P already includes dangling fix-up.
pagerank_solve <- function(L, d = 0.85, v = rep(1 / nrow(L), nrow(L))) {
  n <- nrow(L); out <- rowSums(L)
  P <- L / ifelse(out == 0, 1, out)
  P[out == 0, ] <- matrix(v, sum(out == 0), n, byrow = TRUE)
  as.vector(solve(t(diag(n) - d * P), (1 - d) * v))
}

#' Random directed web: preferential attachment on in-links, with some
#' dangling pages.
make_web <- function(n, out_links = 3, dangling_share = 0.05) {
  L <- matrix(0, n, n)
  indeg <- rep(1, n)
  for (i in seq_len(n)) {
    if (runif(1) < dangling_share) next
    k <- min(out_links, n - 1)
    cand <- setdiff(seq_len(n), i)
    tg <- cand[sample.int(length(cand), k, prob = indeg[cand])]
    L[i, tg] <- 1; indeg[tg] <- indeg[tg] + 1
  }
  L
}
