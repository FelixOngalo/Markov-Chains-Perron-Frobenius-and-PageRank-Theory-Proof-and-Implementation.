library(dplyr)
library(tibble)
source("R/markov_functions.R")
set.seed(2026)

# ---------------------------------------------------------------------
cat("=== 1. Perron-Frobenius for a strictly positive stochastic matrix ===\n")
n <- 8
P <- matrix(runif(n * n), n, n) + 0.05; P <- P / rowSums(P)
ev <- eigen(P)
mods <- sort(Mod(ev$values), decreasing = TRUE)
pi_vec <- stationary_eigen(P)
pf <- tibble(
  top_eigenvalue = Re(ev$values[which.max(Mod(ev$values))]),
  second_modulus = mods[2],
  stationary_min = min(pi_vec),
  stationarity_gap = max(abs(pi_vec %*% P - pi_vec)),
  doeblin_delta = doeblin_delta(P),
  dobrushin = dobrushin(P))
print(pf)

# ---------------------------------------------------------------------
cat("\n=== 2. Contraction: TV(mu P, nu P) <= dobrushin(P) * TV(mu, nu) <= (1 - delta) * TV(mu, nu) ===\n")
contraction <- bind_rows(lapply(1:2000, function(i) {
  mu <- rexp(n); mu <- mu / sum(mu); nu <- rexp(n)^2; nu <- nu / sum(nu)
  tibble(ratio = tv(mu %*% P, nu %*% P) / tv(mu, nu))
}))
contraction_summary <- tibble(max_ratio = max(contraction$ratio), dobrushin = pf$dobrushin, one_minus_delta = 1 - pf$doeblin_delta)
print(contraction_summary)

# ---------------------------------------------------------------------
cat("\n=== 3. Mixing of a random walk on a graph: TV decay versus the second eigenvalue ===\n")
A <- make_graph(60, 2)
W <- lazy(walk_matrix(A))
deg <- rowSums(A); pi_g <- deg / sum(deg)
detailed_balance_gap <- max(abs(diag(pi_g) %*% W - t(diag(pi_g) %*% W)))
lam <- sort(Re(eigen(W)$values), decreasing = TRUE)
lambda_star <- max(abs(lam[-1]))
T <- 60
wt <- worst_tv(W, pi_g, T)
pi_min <- min(pi_g)
bound <- 0.5 * sqrt((1 - pi_min) / pi_min) * lambda_star^(0:T)    # reversible-chain spectral bound
slope_fit <- coef(lm(log(wt[11:41]) ~ I(10:40)))[2]
t_mix <- which(wt <= 0.25)[1] - 1
cat("Detailed-balance gap:", format(detailed_balance_gap, digits = 3),
    " pi equals degree/total? gap:", format(max(abs(stationary_eigen(W) - pi_g)), digits = 3), "\n")
cat("Second eigenvalue lambda*:", round(lambda_star, 4), " fitted decay factor exp(slope):", round(exp(slope_fit), 4), "\n")
cat("Spectral bound always above worst-case TV?", all(wt <= bound + 1e-12), "  t_mix(1/4) =", t_mix, "\n")

decay_df <- tibble(t = 0:T, worst_tv = wt, spectral_bound = bound, lambda_star_power = lambda_star^(0:T))

# Periodicity: a bipartite graph (path) makes the non-lazy walk oscillate forever.
Apath <- matrix(0, 6, 6); for (i in 1:5) { Apath[i, i + 1] <- 1; Apath[i + 1, i] <- 1 }
Pp <- walk_matrix(Apath); pi_p <- rowSums(Apath) / sum(Apath)
periodic <- tibble(t = 0:40,
                   plain = tv_decay(Pp, pi_p, 1, 40),
                   lazy = tv_decay(lazy(Pp), pi_p, 1, 40))
cat("Path graph, TV at t = 39 and 40, plain walk:", round(periodic$plain[40], 4), round(periodic$plain[41], 4),
    "  lazy walk:", round(periodic$lazy[40], 6), round(periodic$lazy[41], 6), "\n")

# ---------------------------------------------------------------------
cat("\n=== 4. Hitting times: linear system versus simulation, and Kac's formula ===\n")
target <- 1
h <- hitting_times(W, target)
starts <- c(10, 30, 55)
hit_check <- bind_rows(lapply(starts, function(s) {
  sim <- simulate_hitting(W, s, target, reps = 3000)
  tibble(start = s, exact = h[s], simulated = sim[["mean"]], se = sim[["se"]])
}))
print(hit_check)
return_time <- 1 + sum(W[target, ] * h)            # expected return time to state 1
cat("Expected return time to state 1:", round(return_time, 4), "  Kac: 1/pi_1 =", round(1 / pi_g[target], 4), "\n")

# ---------------------------------------------------------------------
cat("\n=== 5. PageRank ===\n")
Nweb <- 200
L <- make_web(Nweb)
d <- 0.85
G <- google_matrix(L, d)
pr_eig <- stationary_eigen(G)
pr_pow <- pagerank_power(G)
pr_sol <- pagerank_solve(L, d)
pr_gap <- tibble(power_vs_eigen = max(abs(pr_pow$x - pr_eig)), solve_vs_eigen = max(abs(pr_sol - pr_eig)),
                 row_sums_ok = max(abs(rowSums(G) - 1)), dangling_pages = sum(rowSums(L) == 0))
print(pr_gap)

lam2_G <- sort(Mod(eigen(G)$values), decreasing = TRUE)[2]
lam2_P <- sort(Mod(eigen(t(google_matrix(L, 1)))$values), decreasing = TRUE)   # d = 1: the plain chain with dangling fix-up
cat("|lambda_2(G)| =", round(lam2_G, 5), " <= d =", d, "  d * |lambda_2(P)| =", round(d * lam2_P[2], 5), "\n")

damping <- bind_rows(lapply(c(0.5, 0.7, 0.85, 0.95, 0.99), function(dd) {
  Gd <- google_matrix(L, dd)
  it <- pagerank_power(Gd, tol = 1e-10)$iterations
  tibble(d = dd, iterations = it, predicted_upper = ceiling(log(1e-10) / log(dd)),
         lambda2 = sort(Mod(eigen(Gd)$values), decreasing = TRUE)[2])
}))
print(damping)

indeg <- colSums(L)
rank_df <- tibble(page = seq_len(Nweb), pagerank = pr_eig, in_degree = indeg)
spearman <- cor(rank_df$pagerank, rank_df$in_degree, method = "spearman")
cat("Spearman correlation between PageRank and in-degree:", round(spearman, 3), "\n")

saveRDS(list(pf = pf, contraction = contraction, contraction_summary = contraction_summary,
             decay_df = decay_df, periodic = periodic, lambda_star = lambda_star,
             fitted_decay = unname(exp(slope_fit)), t_mix = t_mix, detailed_balance_gap = detailed_balance_gap,
             hit_check = hit_check, return_time = c(computed = return_time, kac = 1 / pi_g[target]),
             pr_gap = pr_gap, lam2_G = lam2_G, damping = damping, rank_df = rank_df, spearman = spearman,
             d = d, Nweb = Nweb),
        "data/clean/results.rds")
