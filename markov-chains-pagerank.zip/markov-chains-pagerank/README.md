# Markov Chains, Perron-Frobenius and PageRank

Finite Markov chains and PageRank implemented from scratch in R: proofs of the
convergence theorem (with an explicit rate), a spectral bound for reversible
chains, Kac's return-time formula, and the PageRank eigenvalue theorem, each
verified numerically.

## Question

How fast does a Markov chain forget its starting point, what controls that
speed, and why does PageRank converge quickly and have a unique answer?

## Key findings

*(Fill in after running: decay factor of the random walk versus its second
eigenvalue, mixing time, PageRank iterations at d = 0.85 versus the worst-case
bound, hitting-time agreement with simulation.)*

## What is in it

- **Contraction lemma:** every zero-sum vector shrinks by 1 - delta under a
  stochastic matrix with Doeblin constant delta; this alone proves existence,
  uniqueness and geometric convergence of the stationary distribution
  (Perron-Frobenius, positive case)
- **Reversible chains:** TV distance bounded by the second eigenvalue,
  via symmetrisation and Cauchy-Schwarz
- **Periodicity:** why a plain walk on a bipartite graph never converges and
  the lazy walk does
- **Hitting times:** a linear system, checked against simulation, plus a
  short proof of Kac's formula (expected return time = 1 / pi)
- **PageRank:** Google matrix, eigenvalue theorem (other eigenvalues are d
  times those of P), power iteration versus a direct linear solve, damping scan

## Tools

R (base linear algebra, `eigen`, `solve`), dplyr, tibble, tidyr, ggplot2, Quarto.
No graph or Markov-chain packages.

## Reproduce

1. `install.packages(c("dplyr", "tibble", "tidyr", "ggplot2", "knitr", "quarto"))`
2. Run `R/01_run_experiments.R` (saves `data/clean/results.rds`)
3. Render `reports/report.qmd`

All data are simulated, so no download is needed.

## Project structure

```
R/markov_functions.R       chains, stationary distribution, TV, contraction constants, hitting times, PageRank
R/01_run_experiments.R     all experiments and checks
reports/report.qmd         theorems, proofs, results and interpretation
data/clean/                saved results (generated)
```

## Limitations

*(fill in; see the report: finite chains only, positive case proved and the
general theorem cited, single simulated graph, dense linear algebra)*
